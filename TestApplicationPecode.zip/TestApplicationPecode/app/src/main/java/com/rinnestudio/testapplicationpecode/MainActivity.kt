package com.rinnestudio.testapplicationpecode

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.adapter.FragmentViewHolder
import androidx.viewpager2.widget.ViewPager2

class MainActivity : AppCompatActivity() {
    private val viewModel: MyViewModel by viewModels()
    private lateinit var viewPager: ViewPager2
    private lateinit var screenSlidePagerAdapter: ScreenSlidePagerAdapter
    private var count = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        createNotificationChannel()

        viewPager = findViewById(R.id.viewPager)

        screenSlidePagerAdapter = ScreenSlidePagerAdapter(this)

        viewPager.adapter = screenSlidePagerAdapter
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                updateItemCount(position)
            }
        })

        viewModel.destination.observe(this){
            changeCurrentItem(it)
        }
    }

    private inner class ScreenSlidePagerAdapter(fa: FragmentActivity) : FragmentStateAdapter(fa) {
        override fun getItemCount(): Int = count

        override fun createFragment(position: Int): Fragment {
            Log.i("Log_tag", "$position, $itemCount")
            return MyFragment(position)
        }

    }

    private fun updateItemCount(position: Int) {
        if (position == count - 1) {
            count++
            screenSlidePagerAdapter.notifyDataSetChanged()
        }
    }

    private fun changeCurrentItem(destination: Int) {
        if (count < destination) {
            count = destination
            screenSlidePagerAdapter.notifyDataSetChanged()
        }
        viewPager.currentItem = destination
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "CHANNEL_NAME"
            val descriptionText = "description"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel("CHANNEL_ID", name, importance)
            channel.description = descriptionText
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)

        }
    }
}