package com.rinnestudio.testapplicationpecode

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat.getSystemService
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.google.android.material.card.MaterialCardView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MyFragment(private var position: Int) : Fragment() {
    private val viewModel: MyViewModel by activityViewModels()
    private val CHANNEL_NAME = "Notification"
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.test_layot, container, false)

        var notification = NotificationCompat.Builder(requireContext(), "CHANNEL_ID")
            .setContentTitle("You create a notification")
            .setContentText("Notification ${position + 1}")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        view.findViewById<TextView>(R.id.textView2).text = "${position + 1}"

        view.findViewById<FloatingActionButton>(R.id.floatingActionButton3).setOnClickListener {
            viewModel.destination.value = position + 1
        }

        view.findViewById<FloatingActionButton>(R.id.floatingActionButton).setOnClickListener {
            viewModel.destination.value = position - 1
        }

        view.findViewById<MaterialCardView>(R.id.MaterialCardView).setOnClickListener {
            with(NotificationManagerCompat.from(requireContext())) {
                // notificationId is a unique int for each notification that you must define
                notify(position+1, notification.build())
            }
        }


        return view
    }


}